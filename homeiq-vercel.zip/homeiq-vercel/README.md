# HomeIQ — Vercel Deployment

## Files
```
homeiq-vercel/
├── api/
│   ├── analyze.js     ← Claude API proxy
│   └── scrape.js      ← homes.com / Zillow / Redfin scraper
├── public/
│   └── index.html     ← Full frontend
├── vercel.json        ← Routing config
└── README.md
```

## Deploy Steps

### 1. Push to GitHub
- Create new repo on github.com
- Upload all files maintaining folder structure

### 2. Connect to Vercel
- Go to vercel.com → New Project
- Import your GitHub repo
- Framework: Other
- Root directory: ./
- Click Deploy

### 3. Add Environment Variable
- Vercel Dashboard → Your Project → Settings → Environment Variables
- Add: ANTHROPIC_API_KEY = your key from console.anthropic.com

### 4. Redeploy
- Vercel Dashboard → Deployments → Redeploy

Your URL: https://your-project.vercel.app
